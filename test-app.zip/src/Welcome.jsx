 export default function Welcome(props){
  return <h1>안녕, {props.name}</h1>
 }

 

/* function Welcome(props){
    return <h1>안녕, {props.name}</h1>;
} */

/* const element = <Welcome name="인제" />;
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(element); */