import React from "react";
import logo from "./logo.svg";
import "./App.css";
import Example from "./Eaxmple.js";

function App() {
  return (
    <div>
      <Example />
    </div>
  );
}

export default App;